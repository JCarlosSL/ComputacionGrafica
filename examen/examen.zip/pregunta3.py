import numpy as np
import cv2 as cv

vecinos=[[-1,-1],[-1,0],[0,+1],
        [0,-1],[0,+1],
        [+1,-1],[+1,0],[+1,+1]]

def promedio(img,h,k):
    n=len(vecinos)
    suma=0
    for i in range(n):
        suma+=img[vecinos[i][0]+h,vecinos[i][1]+k]
    prom=suma/n
    return prom

def Threashold(img,C=0):
        rows,cols =img.shape
        newMatrix=[[] for i in range(rows)]
        for i in range(rows):
                for j in range(cols):
                        newMatrix[i].append(promedio(img,i,j)) 
        return np.array(newMatrix)

img = cv.imread('question_3.png',0)
new = Threashold(img,20)

cv.imwrite('newquestion3.png',new)
